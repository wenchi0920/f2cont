<?
$wm_width = "150";
$wm_height = "150";
$wm_position = "6";
$wm_image = "plugins/watermark/watermark.png";
$wm_text = "http://10.1.0.101/f2beta/";
$wm_font = "5";
$wm_color = "#FF0000";
$wm_transparence = "85"; 
?>