<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="utf-8">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Language" content="utf-8" />
<meta name="robots" content="all" />
<meta name="author" content="greenteacn[a]gmail.com,绿茶|joesenhong[a]yahoo.com.cn,骆驼" />
<meta name="Copyright" content="F2Blog CopyRight 2006" />
<meta name="keywords" content="f2blog,phpblog,blog,php,xhtml,css,design,w3c,w3cn,Joesen,天上的骆驼" />
<meta name="description" content="My F2Blog - Free &amp; Freedom Blog" />
<title>天上的骆驼-GTMusic 绿茶馆儿-F2Blog专用版</title>
<script>
window.onerror=function(){
event.returnValue=false
} 
</script>
</head>
<frameset rows="*,0" framespacing="0" frameborder="NO" border="0">
  <frame src="../../index.php" name="Greentea" scrolling="yes" target="footnotes" > 
  <frame src="conn/player.HTM" name="player" scrolling="no">
</frameset>
<noframes>
<META HTTP-EQUIV="refresh" CONTENT="1; URL=../../index.php"></noframes>

</html>