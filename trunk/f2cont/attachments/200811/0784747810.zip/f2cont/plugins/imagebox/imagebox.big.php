<div id="Content_Album" style="margin-top:20px;">
<object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0' width='760' height='600'>
      <param name='movie' value='plugins/imagebox/<?php echo $settingInfo['language']?>.swf?path=plugins/imagebox/bilder/' />
      <param name='quality' value='high' />
	  <param name='wmode' value='transparent'>
      <embed src='plugins/imagebox/<?php echo $settingInfo['language']?>.swf?path=plugins/imagebox/bilder/' quality='high' wmode='transparent' pluginspage='http://www.macromedia.com/go/getflashplayer' type='application/x-shockwave-flash' width='760' height='600'></embed>
    </object>
</div>