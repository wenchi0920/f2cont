<?
$bgcolor = "#FFFFFF";
$txtcolor = "#000000"; 
$imgtype = "png";
?>