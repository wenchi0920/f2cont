// UK lang variables

tinyMCE.addToLang('emotions',{
title : '插入表情图示',
desc : '表情图示',
cool : '酷喔',
cry : '大哭',
embarassed : '好糗呀',
foot_in_mouth : '臭死了',
frown : '哼！懒得理你',
innocent : '我是无辜的',
kiss : '亲一个',
laughing : '太可笑喽',
money_mouth : '好高兴喔',
sealed : '闭嘴',
smile : '微笑',
surprised : '惊讶',
tongue_out : '吐舌头',
undecided : '我想想',
wink : '眨眼',
yell : '衰死了～～'
});
