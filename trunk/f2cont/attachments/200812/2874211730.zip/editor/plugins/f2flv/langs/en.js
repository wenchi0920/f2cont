// UK lang variables

tinyMCE.addToLang('flv',{
title : 'Insert / edit Flv file',
desc : 'Insert / edit Flv file',
file : 'FLV-File',
f2desc : 'FLV-Title',
size : 'Size',
list : 'FLV files',
props : 'FLV properties',
general : 'General'
});
