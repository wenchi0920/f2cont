// Simplified Chinese lang variables

tinyMCE.addToLang('flv',{
title : '插入/ 修改 FLV文件',
desc : '插入/ 修改 FLV文件',
file : 'FLV文件网址',
f2desc : 'FLV文件介绍',
size : '尺寸',
list : 'FLV插件列表',
props : '属性',
general : '普通'
});
