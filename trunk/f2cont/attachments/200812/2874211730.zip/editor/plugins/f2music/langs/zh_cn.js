// Simplified Chinese lang variables

tinyMCE.addToLang('Music',{
title : '插入/ 修改 音乐文件',
desc : '插入/ 修改 音乐',
file : '音乐文件网址',
f2desc : '音乐文件介绍',
size : '尺寸',
list : '音乐插件列表',
props : '属性',
general : '普通'
});
