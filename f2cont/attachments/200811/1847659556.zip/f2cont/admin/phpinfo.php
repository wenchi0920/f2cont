<?php  
include("./function.php");

check_login();

echo phpinfo(); 
?>