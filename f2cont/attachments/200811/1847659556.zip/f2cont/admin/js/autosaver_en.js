//自动保存语言包

var autosave_time = " 's will auto save.";
var autosave_wait = "save ...";
var autosave_ok   = "save ok";
var autosave_error= "Auto save failed.";
var autosave_disable="Autosaver disabled.";
