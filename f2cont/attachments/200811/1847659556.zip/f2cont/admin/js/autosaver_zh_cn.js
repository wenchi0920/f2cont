//自动保存语言包

var autosave_time = " 秒后自动保存";
var autosave_wait = "正在保存...";
var autosave_ok   = "已自动保存。";
var autosave_error= "自动保存错误。";
var autosave_disable="禁止自动保存";
