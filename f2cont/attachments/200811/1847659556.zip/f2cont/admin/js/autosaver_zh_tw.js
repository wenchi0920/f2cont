//自動保存語言包

var autosave_time = " 秒後自動保存";
var autosave_wait = "正在保存...";
var autosave_ok   = "已自動保存。";
var autosave_error= "自動保存錯誤。";
var autosave_disable="禁止自動保存";