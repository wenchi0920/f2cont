<?php 
//本设定为特别设定，一般情况是不需要修改的。请慎改。

$cookiedomain = ''; 			// cookie domain
								// cookie 作用域

$cookiepath = '/';				// cookie path
								// cookie 作用路径

$sessionpath = '';				// 保存session的位置，为空表示使用php.ini设定的session path，请使用完整路径。如d:\www\temp
?>