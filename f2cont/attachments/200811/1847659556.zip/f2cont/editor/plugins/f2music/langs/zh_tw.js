// Simplified Chinese lang variables

tinyMCE.addToLang('Music',{
title : '插入/ 修改 音樂文件',
desc : '插入/ 修改 音樂',
file : '音樂文件網址',
f2desc : '音樂文件介紹',
size : '尺寸',
list : '音樂插件列表',
props : '屬性',
general : '普通'
});
