// UK lang variables

tinyMCE.addToLang('Music',{
title : 'Insert / edit Music Movie',
desc : 'Insert / edit Music Movie',
file : 'Music-File',
f2desc : 'Music-Title',
size : 'Size',
list : 'Music files',
props : 'Music properties',
general : 'General'
});
