// Simplified Chinese lang variables

tinyMCE.addToLang('flv',{
title : '插入/ 修改 FLV文件',
desc : '插入/ 修改 FLV',
file : 'FLV文件網址',
f2desc : 'FLV文件介紹',
size : '尺寸',
list : 'FLV插件列表',
props : '屬性',
general : '普通'
});
