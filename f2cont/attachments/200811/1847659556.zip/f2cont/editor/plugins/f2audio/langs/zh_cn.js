// Simplified Chinese lang variables

tinyMCE.addToLang('audio',{
title : '插入/ 修改 MP3文件',
desc : '插入/ 修改 MP3文件',
file : 'MP3文件网址',
f2desc : 'FMP3文件介绍',
size : '尺寸',
list : 'MP3插件列表',
props : '属性',
general : '普通'
});
