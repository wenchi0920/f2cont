// Simplified Chinese lang variables

tinyMCE.addToLang('audio',{
title : '插入/ 修改 MP3文件',
desc : '插入/ 修改 MP3',
file : 'MP3文件網址',
f2desc : 'MP3文件介紹',
size : '尺寸',
list : 'MP3插件列表',
props : '屬性',
general : '普通'
});
