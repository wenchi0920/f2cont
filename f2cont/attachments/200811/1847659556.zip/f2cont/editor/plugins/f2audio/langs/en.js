// UK lang variables

tinyMCE.addToLang('audio',{
title : 'Insert / edit MP3 file',
desc : 'Insert / edit MP3 file',
file : 'MP3-File',
f2desc : 'MP3-Title',
size : 'Size',
list : 'MP3 files',
props : 'MP3 properties',
general : 'General'
});
